import React from 'react'

function Workspace() {
  return (
    <div>Workspace</div>
  )
}

export default Workspace