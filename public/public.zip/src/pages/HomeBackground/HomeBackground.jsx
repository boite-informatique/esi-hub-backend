import React from 'react'
import './HomeBackground.css'
import photo2 from '../LoginRegister/Background/ho.png'
import photo1 from '../LoginRegister/Background/img33.png'
const HBackground = () => {
  return (
<div id="avatar" className="HomeBackground">
<img src={photo2} alt='cv chweya' className="hel" />


   </div>
  )
}

export default HBackground