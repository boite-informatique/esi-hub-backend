import React from 'react'
import './Background.css'
import photo2 from './ho.png'
import photo1 from './img33.png'
const Background = () => {
  return (
<div id="avatar">
<img src={photo1} alt='cv chweya' className="hel" />
<img src={photo2} alt='cv chweya' className="hell" />

   </div>
  )
}

export default Background